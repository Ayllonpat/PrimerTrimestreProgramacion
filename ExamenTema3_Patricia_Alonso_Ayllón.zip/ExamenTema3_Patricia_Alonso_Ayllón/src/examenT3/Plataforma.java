package examenT3;

public class Plataforma {
	
	Principal pv;
	Depositos d;
	
	private String lista[];

	public Plataforma(String[] lista) {
		super();
		this.lista = lista;
	}
	
	public void generarLista() {
		for(int i=0;i<lista.length;i++) {
			d.toString();
		}
	}
	
	public void sumarLista() {}

}
