package ejercicio07;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Calcular el precio final de una compra de un solo producto, pidiendo por teclado el precio 
			del producto, la cantidad que se lleva y el porcentaje de descuento que se le aplica, pero solo 
			si el total es mayor de 100 €. Si no es superior, se mostrará el mensaje "No hay descuento".
		 */

		Scanner sc=new Scanner(System.in);
		
		String aux;
		                           
		
		System.out.println("-----------------------------------");
		System.out.println("Bienvenido al ejercicio 7.");
		System.out.println("-----------------------------------");

		System.out.println("Vamos a calcular la media de 3 notas.");
		
	}

}
