package ejercicio06;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Crear una clase llamada Generadora sin atributos, pero con varios métodos que generen aleatoriamente
		distintos números o resultados según las características del sorteo o para qué se vaya a usar, por ejemplo,
		generar 1, x, 2 para una quiniela, generar par o impar para jugar a pares o nones, generar 1, 2 o 3 para jugar
		a los "chinos", del 1 al 49 para el sorteo de primitiva... Crear una clase principal donde se prueben todos
		los métodos pidiendo los datos necesarios para cada generación.

		 */

	}

}
