package ejercicio05;

public class Copiado {
	
	public void Copiar( String frase, int numeroCopiado) {
		for(int i=0;i<numeroCopiado;i++) {
			System.out.println(frase);
		}
	}
	
	
	
}
